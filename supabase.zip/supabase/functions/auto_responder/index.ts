// supabase/functions/auto_responder/index.ts
import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js";

serve(async (req) => {
    const { record } = await req.json();
    const message = record.content;
    const message_id = record.id;

  // Generate reply using GPT
    const openaiRes = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
        Authorization: `Bearer ${Deno.env.get("OPENAI_KEY")}`,
        "Content-Type": "application/json"
    },
    body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [
        {
            role: "system",
            content: "You are a helpful and friendly assistant who replies to user questions with short, informative answers."
        },
        { role: "user", content: message }
        ]
    })
    });

    const openaiData = await openaiRes.json();
    const replyText = openaiData.choices?.[0]?.message?.content || "Thanks for your message!";

  // Save reply to Supabase
    const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!
    );

    await supabase.from("replies").insert({
    message_id: message_id,
    reply: replyText
    });

    return new Response("Reply saved successfully!");
});
